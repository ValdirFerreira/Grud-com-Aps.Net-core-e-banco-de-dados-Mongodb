﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using WebMongodbWeb.Models;

namespace WebMongodbWeb.Controllers
{
    public class UsuariosController : Controller
    {
        public IActionResult Index()
        {
            ContextoMongodb dbContext = new ContextoMongodb();
            List<Usuario> listaUsuarios = dbContext.Usuario.Find(m => true).ToList();
            return View(listaUsuarios);
        }

        [HttpGet]
        public IActionResult Edit(Guid id)
        {
            ContextoMongodb dbContext = new ContextoMongodb();
            var entity = dbContext.Usuario.Find(m => m.Id == id).FirstOrDefault();
            return View(entity);
        }

        [HttpPost]
        public IActionResult Edit(Usuario entity)
        {
            ContextoMongodb dbContext = new ContextoMongodb();
            dbContext.Usuario.ReplaceOne(m => m.Id == entity.Id, entity);
            return View(entity);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Usuario entity)
        {
            ContextoMongodb dbContext = new ContextoMongodb();
            entity.Id = Guid.NewGuid();
            dbContext.Usuario.InsertOne(entity);
            return RedirectToAction("Index", "Usuarios");
        }

        [HttpGet]
        public IActionResult Delete(Guid id)
        {
            ContextoMongodb dbContext = new ContextoMongodb();
            dbContext.Usuario.DeleteOne(m => m.Id == id);
            return RedirectToAction("Index", "Usuarios");
        }

    }
}